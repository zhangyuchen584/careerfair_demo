import numpy as np
import re
from nltk.tokenize import TweetTokenizer

tknz = TweetTokenizer()

# def clean_str(string):
# #     newString = string.replace('.',' ').replace('#','')
# #     parts = newString.split()
# #     parts = filter(lambda z : z.startswith('@') == False, parts)
# #     newString = ' '.join(parts)
# #     return newString
#     string = re.sub(r"[^A-Za-z0-9(),!?\'\`]", " ", string)
#     string = re.sub(r"\'s", " \'s", string)
#     string = re.sub(r"\'ve", " \'ve", string)
#     string = re.sub(r"n\'t", " n\'t", string)
#     string = re.sub(r"\'re", " \'re", string)
#     string = re.sub(r"\'d", " \'d", string)
#     string = re.sub(r"\'ll", " \'ll", string)
#     string = re.sub(r",", " , ", string)
#     string = re.sub(r"!", " ! ", string)
#     string = re.sub(r"\(", " \( ", string)
#     string = re.sub(r"\)", " \) ", string)
#     string = re.sub(r"\?", " \? ", string)
#     string = re.sub(r"\s{2,}", " ", string)
#     print string
#     return string

def clean_str(string):
    newString = string
    parts = newString.split()
#     parts = filter(lambda z : z != 'a' and z != 'the' and z != 'an', parts)
#     newString = ' '.join(parts)
#     parts = newString.split()
    n = []
    for part in parts:
        if any(i.isdigit() for i in part):
            continue
        elif part.startswith('@'):
            continue
        elif part == '...':
            n.append('.')
#         elif 'fuck' in part:
#             n.append('fuck')
        elif part.startswith('shit'):
            n.append('shit')
        else:
            n.append(part)
    newString = ' '.join(n)
    return newString

def load_data_and_labels(data_file,filter_neutral=False,list_neutral=None,training=False,target=False,trim=False):
    """
    Loads MR polarity data from files, splits the data into words and generates labels.
    Returns split sentences and labels.
    """
    # Load data from files
#     lines = list(open(data_file, "r").readlines())
    box = []
    lines = list(open(data_file, "r").read().splitlines())
    lines = [s.strip().lower() for s in lines]
    x_text = []
    y = []
    for i in range(len(lines)):
#         print lines[i]
        if filter_neutral == True:
            if list_neutral[i] == 0:
                continue
        lines[i] = lines[i].replace('not bad', 'good').replace('not good','bad')
        s = lines[i].split('\t')
#         print lines[i]
        if target == False:
            if s[1] in box:
                continue
            else:
                box.append(s[1])
            lbl = int(s[0])
            if trim == False:
                sen = s[1]
            else:
                sen = clean_str(s[1])
            x_text.append(sen)
            
            
            if lbl == 0:
                y.append(map(np.float32,[1,0,0]))
            elif lbl == 1:
                y.append(map(np.float32,[0,1,0]))
            else:
                y.append(map(np.float32,[0,0,1]))
        else:
#             print s[2]
            lbl = int(s[1])
            if trim == False:
                sen = s[2]
            else:
                sen = clean_str(s[2])
            mess = []
            parts = re.split('[.;|!?]',sen)
            for i in range(len(parts)):
                part = parts[i].strip()
                if part.startswith(s[0] + ' ') or part.endswith(' ' + s[0]) or (' ' + s[0] + ' ') in part:
                    if len(part.split(' ')) - len(s[0].split(' ')) < 5:
                        j = i
                        while j > 0:
                            if len(parts[j-1].strip()) > 0:
                                mess.append(parts[j-1].strip())
                                break
                            else:
                                j -= 1
                        mess.append(part)
                        j = i
                        while j < len(parts)-1:
                            if len(parts[j+1].strip()) > 0:
                                mess.append(parts[j+1].strip())
                                break
                            else:
                                j += 1
                    else:
                        mess.append(part)
            sen = ' '.join(mess)
#             print s[0]
#             print sen
#             print '----------------------------'
            x_text.append(sen)
            
            
            if lbl == 0:
                y.append(map(np.float32,[1,0,0]))
            elif lbl == 1:
                y.append(map(np.float32,[0,1,0]))
            else:
                y.append(map(np.float32,[0,0,1]))
        
        
    y = np.array(y)
    return [x_text, y]


def load_data(sentences, trim=False):
    x_text = []
    y = []
    for sen in sentences:
#         print sen
        sen = sen.lower().encode('utf-8')
        sen = tknz.tokenize(sen)
        if len(sen) > 50:
            sen = sen[:49]
        sen = ' '.join(sen)
        if trim == True:
            sen = clean_str(sen)
#         print sen
        x_text.append(sen)
        y.append(map(np.float32,[0,0,0]))
    y = np.array(y) 
    return x_text, y

    
def batch_iter(data, batch_size, num_epochs, shuffle=True):
    """
    Generates a batch iterator for a dataset.
    """
    data = np.array(data)
    data_size = len(data)
    num_batches_per_epoch = int(len(data)/batch_size) + 1
    for epoch in range(num_epochs):
        # Shuffle the data at each epoch
        if shuffle:
            shuffle_indices = np.random.permutation(np.arange(data_size))
            shuffled_data = data[shuffle_indices]
        else:
            shuffled_data = data
        for batch_num in range(num_batches_per_epoch):
            start_index = batch_num * batch_size
            end_index = min((batch_num + 1) * batch_size, data_size)
            yield shuffled_data[start_index:end_index]
            
def load_ori_target(data_file):
    lines = list(open(data_file, "r").read().splitlines())
    lines = [s.strip().lower() for s in lines]
    target = []
    sentence = []
    for line in lines:
        target.append(line.split('\t')[0])
        sentence.append(line.split('\t')[2])
    return target,sentence
