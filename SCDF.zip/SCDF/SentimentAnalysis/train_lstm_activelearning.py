'''
Created on 20 Dec 2016

@author: luu
'''

import tensorflow as tf
import numpy as np
import os
import time
import datetime
import data_helpers_chinese
from LSTM_Model import LSTM
from tensorflow.contrib import learn
from gensim import models
from tqdm import tqdm
from sklearn.metrics import f1_score
from sklearn.metrics import recall_score
from sklearn.metrics import precision_score
import timeit

# Parameters
# ==================================================

start = timeit.default_timer()

# Data loading params
# tf.flags.DEFINE_string("train_set", "/home/luu/Dropbox/Baidu_dataset/DNN-movie-data/converted/9K.train.processed.tl", "Data source for the training data.")
tf.flags.DEFINE_string("train_set", "/home/luu/Documents/Movie_train.txt", "Data source for the training data.")
tf.flags.DEFINE_string("dev_set", "/home/luu/Dropbox/Baidu_dataset/DNN-movie-data/converted/1K.dev.processed.tl", "Data source for the development data.")
tf.flags.DEFINE_string("test_set", "/home/luu/Dropbox/Baidu_dataset/DNN-movie-data/converted/5K.test.processed.tl", "Data source for the testing data.")
tf.flags.DEFINE_string("remain_set", "/home/luu/Documents/Movie_train_remaining.txt", "Data source for the remaining testing data.")


tf.flags.DEFINE_string("word2vec_embedding", "/home/luu/Downloads/chinese_embeddings/wiki.zh/wiki.zh.vec", "Word2Vec embedding file")
# tf.flags.DEFINE_string("word2vec_embedding", "/home/luu/git/deep_aspect/embeddings/gloveInWord2Vec.840B.300d.txt", "Glove embedding file")

# Model Hyperparameters
tf.flags.DEFINE_integer("hidden_dim", 300, "Dimensionality of hidden layer")
tf.flags.DEFINE_integer("input_dim", 300, "Dimensionality of hidden layer")
tf.flags.DEFINE_float("dropout_keep_prob", 1, "Dropout keep probability (default: 0.5)")
tf.flags.DEFINE_string("filter_sizes", "2,3,4", "Comma-separated filter sizes (default: '3,4,5')")
tf.flags.DEFINE_integer("num_filters", 100, "Number of filters per filter size (default: 100)")
tf.flags.DEFINE_float("l2_reg_lambda", 3.0, "L2 regularizaion lambda (default: 3.0)")
tf.flags.DEFINE_float("learning_rate", 0.0002, "Learning rate (default: 0.001)")

# Training parameters
tf.flags.DEFINE_integer("batch_size", 100, "Batch Size (default: 100)")
tf.flags.DEFINE_integer("num_epochs", 6, "Number of training epochs (default: 5000)")
tf.flags.DEFINE_integer("record_step", 1, "Evaluate model on dev set after this many steps (default: 1)")

FLAGS = tf.flags.FLAGS
FLAGS._parse_flags()
print("\nParameters:")
for attr, value in sorted(FLAGS.__flags.items()):
    print("{}={}".format(attr.upper(), value))
print("")



# Data Preparatopn
# ==================================================

# Load data
print("Loading data...")
x_train, y_train = data_helpers_chinese.load_data_and_labels(FLAGS.train_set)
x_dev, y_dev = data_helpers_chinese.load_data_and_labels(FLAGS.dev_set)
x_test, y_test = data_helpers_chinese.load_data_and_labels(FLAGS.test_set)
x_remain, y_remain = data_helpers_chinese.load_data_and_labels(FLAGS.remain_set)

x_data = x_train + x_dev + x_test + x_remain

idt = 1
id_to_word = {}
word_to_id = {}
id_to_word[0] = '<pad>'
word_to_id['<pad'] = 0
for x in x_data:
    for p in x.split(' '):
        if p in word_to_id:
            continue
        else:
            word_to_id[p] = idt
            id_to_word[idt] = p
            idt += 1

# Build vocabulary
max_document_length = max([len(x.split(" ")) for x in x_data])
#print max_document_length
#vocab_processor = learn.preprocessing.VocabularyProcessor(max_document_length)
#vocab_processor.fit(x_data)

print("Vocabulary Size: {:d}".format(len(id_to_word)))

temp = []
for x in x_train:
    t = []
    for e in x.split(' '):
        t.append(word_to_id[e])
    for i in range(max_document_length - len(x.split(' '))):
        t.append(0)
    t = np.array(t,dtype=np.int32)
    temp.append(t)
x_train = np.array(list(temp),dtype=np.int32)

temp = []
for x in x_test:
    t = []
    for e in x.split(' '):
        t.append(word_to_id[e])
    for i in range(max_document_length - len(x.split(' '))):
        t.append(0)
    t = np.array(t,dtype=np.int32)
    temp.append(t)
x_test = np.array(list(temp),dtype=np.int32)

temp = []
for x in x_dev:
    t = []
    for e in x.split(' '):
        t.append(word_to_id[e])
    for i in range(max_document_length - len(x.split(' '))):
        t.append(0)
    t = np.array(t,dtype=np.int32)
    temp.append(t)
x_dev = np.array(list(temp),dtype=np.int32)

temp = []
for x in x_remain:
    t = []
    for e in x.split(' '):
        t.append(word_to_id[e])
    for i in range(max_document_length - len(x.split(' '))):
        t.append(0)
    t = np.array(t,dtype=np.int32)
    temp.append(t)
x_remain = np.array(list(temp),dtype=np.int32)

# Randomly shuffle data
np.random.seed(123)
tf.set_random_seed(1)





# Load W2V embedding
# ==================================================
# model = models.Word2Vec.load_word2vec_format(FLAGS.word2vec_embedding, binary=False)
initW = np.random.uniform(-0.0001,0.0001,(len(word_to_id), FLAGS.input_dim))
# for word in model.vocab:
#     if word in word_to_id:
#         initW[word_to_id[word]] = model[word]



# print('Start Loading Embedding!')
# filename = "/home/luu/git/deep_aspect/embeddings/glove.840B.300d.txt"
# file = open(filename,'r')
# model = {}
# for line in file.readlines():
#     row = line.strip().split(' ')
#     word = row[0]
#     embedding = [float(val) for val in row[1:]]
#     model[word] = embedding
# print('Finish Loading Embedding!')
# print('Length of embedding is: {:d}'.format(len(model)))
# file.close()
# 
# initW = np.random.uniform(-0.25,0.25,(len(vocab_processor.vocabulary_), 300))
# for word in model:
#     idx = vocab_processor.vocabulary_.get(word)
#     if idx != 0:
#         initW[idx] = model[word]


# Training
# ==================================================

best_acc = 0
best_echo = 0
with tf.Graph().as_default():
    with tf.Session(config=tf.ConfigProto(log_device_placement=False)) as sess:
        np.random.seed(123)
        tf.set_random_seed(1)
        model = LSTM(FLAGS.input_dim, max_document_length, FLAGS.hidden_dim, 3,len(word_to_id), FLAGS.learning_rate)
        
        print "Initialize variable"
        sess.run(tf.global_variables_initializer())
        
        print "Initialize embedding"
        sess.run(model.embedding_init, feed_dict={model.embedding_placeholder:initW})
        
        ################
        # Training batch
        ################
        def get_feed_dict(x, y, batch_number, mode='training'):
            ''' This function returns a feed_dict for training
            Supports both training and testing mode. Just pass in different x,y sets
            batch_number extracts the correct batch, if set to None, returns entire set
            (For testing and evaluation normally we test the entire training set at once and no need to do batching)
        
            Input Arguments
            ---------------
            x : This is either x_train or x_dev
            y: This is either y_train or y_dev
            batch_number: Integer. Indexing the batch, set to None for whole set
            mode: if Training, sets dropout to 0.5, else sets it to 1.0 (Testing cannot use dropout 0.5)
            '''
        
            if(batch_number is not None):
                # Get batch
                X = x[int(batch_number * FLAGS.batch_size):int(int(batch_number * FLAGS.batch_size) + FLAGS.batch_size)]
                Y = y[int(batch_number * FLAGS.batch_size):int(int(batch_number * FLAGS.batch_size) + FLAGS.batch_size)]
                X = np.array(X,dtype=np.int32)
                Y = np.array(Y,dtype=np.float32)
            else:
                # Get entire set as feed_dict
                X = np.array(x, dtype=np.int32)
                Y = np.array(y, dtype=np.float32)
            
            if(mode=='training'):
                drop_val = FLAGS.dropout_keep_prob
            else:
                # Testing should use dropout 1.0
                drop_val = 1.0
        
            feed_dict = {
                        model.input_x:X, 
                        model.input_y:Y,
                        model.dropout_keep_prob:drop_val
                        }
        
            # ptr = batch_number * batch_size
            # for i in range(batch_size):
            #     X.append(x_train[ptr + i])
            #     Y.append(y_train[ptr + i])
            #     print type(y_train[ptr + i][0])
            #     print type(x_train[ptr + i][0])
            # feed_dict = {train_input[t]: X[t] for t in range(batch_size)}
            # feed_dict[dropout_keep_prob]=0.5
            # feed_dict.update({train_output[t]: Y[t] for t in range(batch_size)})
            
            return feed_dict
        
        
        no_of_batches = int(len(x_train)/FLAGS.batch_size)
        print "Start training"
        time_str = datetime.datetime.now().isoformat()
        print(time_str)
        for t in range(FLAGS.num_epochs):
            losses = []
            shuffle_indices = np.random.permutation(np.arange(len(x_train)))
            x_train = x_train[shuffle_indices]
            y_train = y_train[shuffle_indices]
#             for j in tqdm(range(no_of_batches)):
            for j in range(no_of_batches):
                # NOTE : Remove this tqdm is cannot install
                feed_dict = get_feed_dict(x_train, y_train, j)
#                 _, loss = sess.run([model.train_step, model.cross_entropy], feed_dict)
                _, loss = sess.run([model.train_op, model.loss], feed_dict)
                losses.append(loss)
            print("[Epoch {}] Loss={}".format(t+1, np.mean(losses)))
            
            if t % FLAGS.record_step == 0:
                feed_dict = get_feed_dict(x_dev, y_dev, None,'testing')
                pred_ops,predict,acc = sess.run([model.pred_ops,model.predictions,model.accuracy], feed_dict)
                all_labels = []
                for i in y_dev:
                    if i[0] == 1:
                        all_labels.append(0)
                    elif i[1] == 1:
                        all_labels.append(1)
                    else:
                        all_labels.append(2)
                f1 = f1_score(all_labels,predict, average='macro')
                recall = recall_score(all_labels,predict, average='macro')
                precision = precision_score(all_labels,predict, average='macro')
                #if best_acc < acc:
                #    best_acc = acc
                #    best_echo = t+1
                print("[Evaluate] Dev Accuracy={}, F1={}, P={}, R= {}".format(acc,f1,recall,precision))
                        
        
                feed_dict = get_feed_dict(x_test, y_test, None,'testing')
                pred_ops,predict,acc = sess.run([model.pred_ops,model.predictions,model.accuracy], feed_dict)
                all_labels = []
                for i in y_test:
                    if i[0] == 1:
                        all_labels.append(0)
                    elif i[1] == 1:
                        all_labels.append(1)
                    else:
                        all_labels.append(2)
                f1 = f1_score(all_labels,predict, average='macro')
                recall = recall_score(all_labels,predict, average='macro')
                precision = precision_score(all_labels,predict, average='macro')
                print("[Evaluate] Test Accuracy={}, F1={}, P={}, R= {}".format(acc,f1,recall,precision))
                        
                if best_acc < f1:
                    best_acc = f1
                    best_echo = t+1
                    if len(x_remain) == 0:
                        continue
                    feed_dict = get_feed_dict(x_remain, y_remain, None,'testing')
                    pred_ops,predict,_ = sess.run([model.pred_ops,model.predictions,model.accuracy], feed_dict)
                    print pred_ops
                    print predict
                    diff = {}
                    all_labels = []
                    for i in y_remain:
                        if i[0] == 1:
                            all_labels.append(0)
                        elif i[1] == 1:
                            all_labels.append(1)
                        else:
                            all_labels.append(2)
                    for i in range(len(predict)):
                        diff[i] = 1 - pred_ops[i][all_labels[i]]
                    sort = sorted(diff.items(), key=lambda x:x[1], reverse=True)
                    print sort
                    
                    
                    
#                     with open('/home/anhtuan/sentence_level_SA/result/result_dev.txt','w') as f:
#                         for r in pred_ops:
#                             f.write(str(r[0]) + '\t' + str(r[1]) + '\n')
#                     with open('/home/anhtuan/sentence_level_SA/result/result_test.txt','w') as f:
#                         for r in pred_ops:
#                             f.write(str(r[0]) + '\t' + str(r[1]) + '\n')
                
                print("Best F1={} at echo {}".format(best_acc,best_echo))
                print("------------------------------------------------")
#                 time_str = datetime.datetime.now().isoformat()
#                 print(time_str)
        list_r = {}
        count_r = 0
        with open(FLAGS.remain_set,'r') as f:
            lines = f.readlines()
            for line in lines:
                list_r[count_r] = line
                count_r += 1
         
        remove_r = []
        with open(FLAGS.train_set,'a') as f:
            for i in range(500):
                f.write(list_r[sort[i][0]])
                remove_r.append(sort[i][0])
         
        with open(FLAGS.remain_set,'w') as f:
            for k in list_r:
                if k not in remove_r:
                    f.write(list_r[k])  
stop = timeit.default_timer()
print('Processing time is {:f}'.format(stop - start)) 