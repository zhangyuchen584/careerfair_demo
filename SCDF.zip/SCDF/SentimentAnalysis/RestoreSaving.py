'''
Created on 20 Dec 2016

@author: luu
'''

import tensorflow as tf
import numpy as np
import data_helpers_scdf_target_youtube
import preEvaluation_target_youtube
from sklearn.metrics import f1_score
from sklearn.metrics import recall_score
from sklearn.metrics import precision_score
import timeit
import performanceEvaluation

# Parameters
# ==================================================

start = timeit.default_timer()

tf.flags.DEFINE_string("train_set", "../Dataset/Youtube/train_target.txt", "Data source for the training data.")
tf.flags.DEFINE_string("dev_set", "../Dataset/Youtube/dev_target.txt", "Data source for the development data.")
tf.flags.DEFINE_string("test_set", "../Dataset/Youtube/test_target.txt", "Data source for the testing data.")

tf.flags.DEFINE_string("word2vec_embedding", "/home/luu/Downloads/GoogleNews-vectors-negative300.bin", "Word2Vec embedding file")
tf.flags.DEFINE_integer("input_dim", 300, "Dimensionality of hidden layer")

tf.flags.DEFINE_string("lexicon_file", "/home/luu/Downloads/NeutralFillter/lexicon.txt", "Lexicon file.")
tf.flags.DEFINE_string("oneGram_file", "/home/luu/Downloads/NeutralFillter/Toey_onegram.txt", "One gram file.")

FLAGS = tf.flags.FLAGS
FLAGS._parse_flags()
print("\nParameters:")
for attr, value in sorted(FLAGS.__flags.items()):
    print("{}={}".format(attr.upper(), value))
print("")


# Data Preparatopn
# ==================================================

neutral = preEvaluation_target_youtube.checkNeutralFile(FLAGS.lexicon_file, FLAGS.oneGram_file, FLAGS.test_set)
target,sentence = data_helpers_scdf_target_youtube.load_ori_target(FLAGS.test_set)
checkPolarity = preEvaluation_target_youtube.checkPolarity(target,sentence)


# print target
# print sentence

# Load data
print("Loading data...")
x_test, y_test = data_helpers_scdf_target_youtube.load_data_and_labels(FLAGS.test_set,target=True, trim = True)
x_realtest = x_test

word_to_id = {}
with open('../SavedDict/dict.txt','r') as f:
    lines = f.readlines()
    for line in lines:
        parts = line.strip().split('***+++###!!!***')
        word_to_id[parts[0]] = int(parts[1])

# Build vocabulary
max_document_length = 50

 
temp = []
for x in x_test:
    t = []
    for e in x.split(' '):
        t.append(word_to_id[e])
    for i in range(max_document_length - len(x.split(' '))):
        t.append(0)
    t = np.array(t,dtype=np.int32)
    temp.append(t)
x_test = np.array(list(temp),dtype=np.int32)





################
# Training batch
################
def get_feed_dict(x, y, input_ops, batch_number, mode='training'):
    ''' This function returns a feed_dict for training
    Supports both training and testing mode. Just pass in different x,y sets
    batch_number extracts the correct batch, if set to None, returns entire set
    (For testing and evaluation normally we test the entire training set at once and no need to do batching)

    Input Arguments
    ---------------
    x : This is either x_train or x_dev
    y: This is either y_train or y_dev
    batch_number: Integer. Indexing the batch, set to None for whole set
    mode: if Training, sets dropout to 0.5, else sets it to 1.0 (Testing cannot use dropout 0.5)
    '''

    if(batch_number is not None):
        # Get batch
        X = x[int(batch_number * FLAGS.batch_size):int(int(batch_number * FLAGS.batch_size) + FLAGS.batch_size)]
        Y = y[int(batch_number * FLAGS.batch_size):int(int(batch_number * FLAGS.batch_size) + FLAGS.batch_size)]
        X = np.array(X,dtype=np.int32)
        Y = np.array(Y,dtype=np.float32)
    else:
        # Get entire set as feed_dict
        X = np.array(x, dtype=np.int32)
        Y = np.array(y, dtype=np.float32)
    
    if(mode=='training'):
        drop_val = FLAGS.dropout_keep_prob
    else:
        # Testing should use dropout 1.0
        drop_val = 1.0

    feed_dict = {
                input_ops[0]:X, 
                input_ops[1]:Y,
                input_ops[2]:drop_val
                }
    
    return feed_dict

# Training
# ==================================================

saver = tf.train.import_meta_graph("../SavedModels/model.ckpt.meta")

#with tf.Graph().as_default():
with tf.Session() as sess:
    saver.restore(sess,"../SavedModels/model.ckpt")
    input_ops = tf.get_collection('input')
    result_ops = tf.get_collection('result')
    
    
    feed_dict = get_feed_dict(x_test, y_test, input_ops, None,'testing')
    pred_ops,predict,acc = sess.run(result_ops, feed_dict)

    
    all_labels = []
    for i in y_test:
        if i[0] == 1:
            all_labels.append(0)
        elif i[1] == 1:
            all_labels.append(1)
        else:
            all_labels.append(2)
    for i in range(len(neutral)):
        if neutral[i] == 0:
            predict[i] = 1
    for i in range(len(checkPolarity)):
        if checkPolarity[i] == 1 or checkPolarity[i] == 2:
            predict[i] = checkPolarity[i]
        elif checkPolarity[i] == 3:
            predict[i] = 0
        elif checkPolarity[i] == 4:
            predict[i] = 2 - predict[i]
    
    f1 = f1_score(all_labels,predict, average='macro')
    recall = recall_score(all_labels,predict, average='macro')
    precision = precision_score(all_labels,predict, average='macro')
    print("[Evaluate] Test Accuracy={}, F1={}, P={}, R= {}".format(acc,f1,recall,precision))

performanceEvaluation.evaluate(all_labels, predict)
# performanceEvaluation.printout(best_all_labels, best_result, x_realtest)
performanceEvaluation.printout(all_labels, predict,sentence,x_realtest,targetList=target,target=True)
stop = timeit.default_timer()
print('Processing time is {:f}'.format(stop - start))