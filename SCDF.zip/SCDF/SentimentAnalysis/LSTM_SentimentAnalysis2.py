'''
Created on Dec 15, 2016

@author: atluu
'''

import tensorflow as tf
from gensim import models
import numpy as np
import os
import time
import datetime
import data_helpers
from tensorflow.contrib import learn
from collections import Counter
from tqdm import tqdm

# Please run sudo pip install tqdm 
# This module provides fancy progress bars
# If not just remove tqdm in the for loop below

# Load data
print("Loading data...")
x_text, y = data_helpers.load_data_and_labels("./rt-polarity.pos", "./rt-polarity.neg")

# Build vocabulary
max_document_length = max([len(x.split(" ")) for x in x_text])
vocab_processor = learn.preprocessing.VocabularyProcessor(max_document_length)
x = np.array(list(vocab_processor.fit_transform(x_text)),dtype=np.int32)

# Randomly shuffle data
np.random.seed(10)
shuffle_indices = np.random.permutation(np.arange(len(y)))
x_shuffled = x[shuffle_indices]
y_shuffled = y[shuffle_indices]


# Split train/test set
# TODO: This is very crude, should use cross-validation
dev_sample_index = -1 * int(0.1 * float(len(y)))
x_train, x_dev = x_shuffled[:dev_sample_index], x_shuffled[dev_sample_index:]
y_train, y_dev = y_shuffled[:dev_sample_index], y_shuffled[dev_sample_index:]
print("Vocabulary Size: {:d}".format(len(vocab_processor.vocabulary_)))
print("Train/Dev split: {:d}/{:d}".format(len(y_train), len(y_dev)))


###############
#Configurations
###############
word2vec_dim = 300
# sequence_length = x_train.shape[1]
# num_classes = y_train.shape[1]
vocab_size = len(vocab_processor.vocabulary_)
# embedding_size = 300


###########
#LSTM_Model layer
###########

# Parameters
learning_rate = 0.0001
training_iters = 100000
batch_size = 1000
display_step = 10

# Network Parameters
n_input = 300 
n_steps = max_document_length # timesteps
n_hidden = 500 # hidden layer num of features
n_classes = 2 

#Placeholder for input, output and dropout
train_input = tf.placeholder(tf.int32, [None,n_steps])
train_output = tf.placeholder(tf.float32, [None,n_classes])
train_input_embedding = tf.placeholder(tf.float32, [None,n_steps,n_input])
dropout_keep_prob = tf.placeholder(tf.float32)

################
#Embedding layer
################

W = tf.Variable(tf.random_uniform([vocab_size, n_input], -1.0, 1.0),trainable=True, name="W", dtype = tf.float32)
embedding_placeholder = tf.placeholder(tf.float32, [vocab_size, n_input])
embedding_init = W.assign(embedding_placeholder)
with tf.device('/cpu:0'):
    train_input_embedding = tf.nn.embedding_lookup(W, train_input)
    
# sess = tf.Session()
# sess.run(embedding_init, feed_dict={embedding_placeholder: embedding})


###########
#LSTM_Model model
###########
# Define weights
weights = {
    'out': tf.Variable(tf.random_normal([n_hidden, n_classes]))
}
biases = {
    'out': tf.Variable(tf.random_normal([n_classes]))
}

def RNN(x, weights, biases):
    # Prepare data shape to match `rnn` function requirements
    # Current data input shape: (batch_size, n_steps, n_input)
    # Required shape: 'n_steps' tensors list of shape (batch_size, n_input)

    # Permuting batch_size and n_steps
    x = tf.transpose(x, [1, 0, 2])
    # Reshaping to (n_steps*batch_size, n_input)
    x = tf.reshape(x, [-1, n_input])
    # Split to get a list of 'n_steps' tensors of shape (batch_size, n_input)
    x = tf.split(0, n_steps, x)

    # Define a lstm cell with tensorflow
    lstm_cell = tf.nn.rnn_cell.BasicLSTMCell(n_hidden, forget_bias=1.0)
    lstm_cell = tf.nn.rnn_cell.DropoutWrapper(lstm_cell, output_keep_prob=dropout_keep_prob)
    
    # Get lstm cell output
    outputs, states = tf.nn.rnn(lstm_cell, x, dtype=tf.float32)

    # Linear activation, using rnn inner loop last output
    return tf.matmul(outputs[-1], weights['out']) + biases['out']


pred = RNN(train_input_embedding, weights, biases)

# Define loss and optimizer
cost = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(pred, train_output))
optimizer = tf.train.AdamOptimizer(learning_rate=learning_rate).minimize(cost)

train_op = optimizer

# Evaluate model
correct_pred = tf.equal(tf.argmax(pred,1), tf.argmax(train_output,1))
accuracy = tf.reduce_mean(tf.cast(correct_pred, tf.float32))


################
# Training batch
################
def get_feed_dict(x, y, batch_number, mode='training'):
    ''' This function returns a feed_dict for training
    Supports both training and testing mode. Just pass in different x,y sets
    batch_number extracts the correct batch, if set to None, returns entire set
    (For testing and evaluation normally we test the entire training set at once and no need to do batching)

    Input Arguments
    ---------------
    x : This is either x_train or x_dev
    y: This is either y_train or y_dev
    batch_number: Integer. Indexing the batch, set to None for whole set
    mode: if Training, sets dropout to 0.5, else sets it to 1.0 (Testing cannot use dropout 0.5)
    '''

    if(batch_number is not None):
        # Get batch
        X = x[int(batch_number * batch_size):int(int(batch_number * batch_size) + batch_size)]
        Y = y[int(batch_number * batch_size):int(int(batch_number * batch_size) + batch_size)]
        X = np.array(X,dtype=np.int32)
        Y = np.array(Y,dtype=np.float32)
    else:
        # Get entire set as feed_dict
        X = np.array(x, dtype=np.int32)
        Y = np.array(y, dtype=np.float32)
    
    if(mode=='training'):
        drop_val = 0.5
    else:
        # Testing should use dropout 1.0
        drop_val = 1.0

    feed_dict = {
                train_input:X, 
                train_output:Y,
                dropout_keep_prob:drop_val
                }

    # ptr = batch_number * batch_size
    # for i in range(batch_size):
    #     X.append(x_train[ptr + i])
    #     Y.append(y_train[ptr + i])
    #     print type(y_train[ptr + i][0])
    #     print type(x_train[ptr + i][0])
    # feed_dict = {train_input[t]: X[t] for t in range(batch_size)}
    # feed_dict[dropout_keep_prob]=0.5
    # feed_dict.update({train_output[t]: Y[t] for t in range(batch_size)})
    
    return feed_dict


###################
#Load W2V embedding
###################
model = models.Word2Vec.load_word2vec_format("/home/luu/Downloads/GoogleNews-vectors-negative300.bin", binary=True)
embedding = model.syn0
initW = np.random.uniform(-0.25,0.25,(len(vocab_processor.vocabulary_), word2vec_dim))
for word in model.vocab:
    idx = vocab_processor.vocabulary_.get(word)
    if idx != 0:
        initW[idx] = model[word]
    

#########
#Training
#########
with tf.Session(config=tf.ConfigProto(log_device_placement=False)) as sess:
    num_echo = 5000
    record_step = 2
    print "Initialize variable"
    sess.run(tf.initialize_all_variables())
    print "Initialize embedding"
    sess.run(embedding_init, feed_dict={embedding_placeholder:initW})
    no_of_batches = int(len(x_train)/batch_size)
    print "Start training"
    for t in range(num_echo):
        losses = []
        for j in tqdm(range(no_of_batches)):
            # NOTE : Remove this tqdm is cannot install
            feed_dict = get_feed_dict(x_train, y_train, j)
            _, loss = sess.run([train_op, cost], feed_dict)
            losses.append(loss)
        print("[Epoch {}] Loss={}".format(t+1, np.mean(losses)))
        if t % record_step == 0:
            feed_dict = get_feed_dict(x_dev, y_dev, None)
            acc = sess.run([accuracy], feed_dict)
            print("[Evaluate] Accuracy={}".format(acc))
    
