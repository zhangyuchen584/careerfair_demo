import random

def checkNeutralFile(lexFile,oneGramFile,test):
    result = []
    list = []
    with open(lexFile,'r') as f:
        lines = f.readlines()
        for line in lines:
            word = line.strip()
            list.append(word)
       
    with open(oneGramFile,'r') as f:
        lines = f.readlines()
        for line in lines:
            word = line.strip()
            list.append(word)
            if word.startswith('#') == False:
                list.append('#' + word)
    
    
    n_grams = ['jia you','so long','in blue','not suppose to be','dig out','wah lao','look forward',': 3','cant wait','can\'t wait', 'don\'t wanna','no choice','dream come true','cannot make it','oh god','break my heart',
               '~ _ ~','- ___ -',': , )',': " )','> = <','_ | _','-.-','- . -','- _ -',')-:','cant accept','looking forward','at last','can\'t w8','not acceptable',': (','; _ ;','^ . ^','; - ;','blood starving','bo pian','barely breathing',
               'missing out','good luck','too much','so blessed','^ ^','b o r i n g','thanks',': o ','can\'t stand ','cnnt pass','not my day',': " (','don\'t want','well done','monday blues']
    long_words = ['party','stress','god','fuck','celebrat','bitch','dread','suck','whoop','laugh','thankful','congrat','happy','love','haiss','haizz','huhu','#ilove','shit','hehe', 'aaa','bbb','ccc','ddd','eee','fff','ggg','hhh','iii','jjj','kkk','lll','mmm','nnn','ooo','ppp','qqq','rrr','sss','ttt','uuu','vvv','xxx','yyy','zzz']
        
    count = 0
    with open(test,'r') as f:
        lines = f.read().splitlines()
        for line in lines:
            line = line.strip().lower()
            parts = line.split()
            flag = True
            for p in parts:
                if p in list:
                    flag = False
                    break
                if p.startswith('shit'):
                    flag = False
                    break
                if len(p) > 3 and p.endswith('www'):
                    flag = False
                    break
            if flag:
                for p in n_grams:
                    if p in line:
                        flag = False
                        break
            if flag:
                for p in long_words:
                    if p in line:
                        flag = False
                        break
            if flag:         
                result.append(0)
                count += 1
            else:
                result.append(1)
    
#     print('Number of predicted neutrals :{}'.format(count))
    return result


def checkNeutralSentences(lexFile,oneGramFile,sentences):
    result = []
    list = []
    with open(lexFile,'r') as f:
        lines = f.readlines()
        for line in lines:
            word = line.strip()
            list.append(word)
       
    with open(oneGramFile,'r') as f:
        lines = f.readlines()
        for line in lines:
            word = line.strip()
            list.append(word)
            if word.startswith('#') == False:
                list.append('#' + word)
    
    
    n_grams = ['jia you','so long','in blue','not suppose to be','dig out','wah lao','look forward',': 3','cant wait','can\'t wait', 'don\'t wanna','no choice','dream come true','cannot make it','oh god','break my heart',
               '~ _ ~','- ___ -',': , )',': " )','> = <','_ | _','-.-','- . -','- _ -',')-:','cant accept','looking forward','at last','can\'t w8','not acceptable',': (','; _ ;','^ . ^','; - ;','blood starving','bo pian','barely breathing',
               'missing out','good luck','too much','so blessed','^ ^','b o r i n g','thanks',': o ','can\'t stand ','cnnt pass','not my day',': " (','don\'t want','well done','monday blues']
    long_words = ['party','stress','god','fuck','celebrat','bitch','dread','suck','whoop','laugh','thankful','congrat','happy','love','haiss','haizz','huhu','#ilove','shit','hehe', 'aaa','bbb','ccc','ddd','eee','fff','ggg','hhh','iii','jjj','kkk','lll','mmm','nnn','ooo','ppp','qqq','rrr','sss','ttt','uuu','vvv','xxx','yyy','zzz']
        
    count = 0
    
    for line in sentences:
        line = line.strip().lower()
        parts = line.split()
        flag = True
        for p in parts:
            if p in list:
                flag = False
                break
            if len(p) > 3 and p.endswith('www'):
                flag = False
                break
        if flag:
            for p in n_grams:
                if p in line:
                    flag = False
                    break
        if flag:
            for p in long_words:
                if p in line:
                    flag = False
                    break
        if flag:         
            result.append(0)
            count += 1
        else:
            result.append(1)
    
#     print('Number of predicted neutrals :{}'.format(count))
    return result

def checkPolarity(target,sentence):
    result = []
    for tar,sen in zip(target,sentence):
        flag = 0
        if ('don\'t want to ' + tar) in sen or ('do not want to ' + tar) in sen or ('do not want ' + tar) in sen\
         or (' better than ' + tar) in sen or (' better than the ' + tar) in sen \
         or (' easier than ' + tar) in sen or (' easier than the ' + tar) in sen \
         or (tar + ' hell ') in sen or (' hell ' + tar) in sen:
            flag = 3
        elif ('can\'t wait to ' + tar) in sen or ('can not wait to ' + tar) in sen or ('want to ' + tar) in sen\
         or (' can\'t wait to the ' + tar) in sen or (' worse than the ' + tar) in sen\
         or ('want to join ' + tar) in sen or ('want to join the ' + tar) in sen\
         or (' harder than ' + tar) in sen or (' harder than the ' + tar) in sen\
         or (' gold for ' + tar) in sen\
         or ('miss ' + tar) in sen or ('miss my ' + tar) in sen\
         or ('missing ' + tar) in sen or ('missing my ' + tar) in sen:
        # or ('want ' + tar) in sen or (' worse than ' + tar) in sen\
            flag = 2
        elif (' @ ' + tar) in sen\
         or (' # ' + tar) in sen\
         or (' at the ' + tar) in sen\
         or (' near the ' + tar) in sen\
         or (' around the ' + tar) in sen\
         or (' from the ' + tar) in sen\
         or (' before the ' + tar) in sen\
         or (' after the ' + tar) in sen\
         or (' at ' + tar) in sen\
         or (' near ' + tar) in sen\
         or (' around ' + tar) in sen\
         or (' from ' + tar) in sen\
         or (' before ' + tar) in sen\
         or (' after ' + tar) in sen\
         or (' in the ' + tar + ' @') in sen\
         or (' in the ' + tar + ' #') in sen\
         or (' in the ' + tar + ' ,') in sen\
         or (' in the ' + tar + ' .') in sen\
         or sen.endswith(' in the ' + tar)\
         or (' in ' + tar + ' @') in sen\
         or (' in ' + tar + ' #') in sen\
         or (' in ' + tar + ' ,') in sen\
         or (' in ' + tar + ' .') in sen:
        #\or sen.endswith(' in ' + tar):
        #or (' around ' + tar) in sen or (' to ' + tar) in sen\
        #or (' after ' + tar) in sen or (' on ' + tar) in sen or (' from ' + tar) in sen or (' for ' + tar) in sen or (' before ' + tar) in sen \:
#         or (' in ' + tar + ' @') in sen\
#          or (' in ' + tar + ' #') in sen\
#          or (' in ' + tar + ' ,') in sen\
#          or (' in ' + tar + ' .') in sen\
#          or (' to ' + tar + ' @') in sen\
#          or (' to ' + tar + ' #') in sen\
#          or (' to ' + tar + ' ,') in sen\
#          or (' to ' + tar + ' .') in sen\
#          or sen.endswith(' in ' + tar)\
#          or sen.endswith(' to ' + tar)\
            flag = 1
        elif  (' compared to ' + tar) in sen:
            flag = 4
        result.append(flag)
    return result
    