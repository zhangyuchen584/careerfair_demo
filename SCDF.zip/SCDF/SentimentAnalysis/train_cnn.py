'''
Created on 20 Dec 2016

@author: luu
'''

import tensorflow as tf
import numpy as np
import os
import time
import datetime
import data_helpers
from CNN_Model import CNN
from tensorflow.contrib import learn
from gensim import models
from tqdm import tqdm

# Parameters
# ==================================================

# Data loading params
tf.flags.DEFINE_float("dev_sample_percentage", .1, "Percentage of the training data to use for validation")
tf.flags.DEFINE_string("data_source_positive", "./rt-polarity.pos", "Data source for the positive data.")
tf.flags.DEFINE_string("data_source_negative", "./rt-polarity.neg", "Data source for the negative data.")
tf.flags.DEFINE_string("word2vec_embedding", "/home/luu/Downloads/GoogleNews-vectors-negative300.bin", "Word2Vec embedding file")
# tf.flags.DEFINE_string("word2vec_embedding", "/home/luu/git/deep_aspect/embeddings/gloveInWord2Vec.840B.300d.txt", "Glove embedding file")

# Model Hyperparameters
tf.flags.DEFINE_integer("hidden_dim", 300, "Dimensionality of hidden layer")
tf.flags.DEFINE_float("dropout_keep_prob", 0.5, "Dropout keep probability (default: 0.5)")
tf.flags.DEFINE_string("filter_sizes", "3,4,5", "Comma-separated filter sizes (default: '3,4,5')")
tf.flags.DEFINE_integer("num_filters", 100, "Number of filters per filter size (default: 128)")
tf.flags.DEFINE_float("l2_reg_lambda", 3.0, "L2 regularizaion lambda (default: 0.0)")
tf.flags.DEFINE_float("learning_rate", 0.0001, "Learning rate (default: 0.001)")

# Training parameters
tf.flags.DEFINE_integer("batch_size", 100, "Batch Size (default: 128)")
tf.flags.DEFINE_integer("num_epochs", 5000, "Number of training epochs (default: 5000)")
tf.flags.DEFINE_integer("record_step", 1, "Evaluate model on dev set after this many steps (default: 2)")

FLAGS = tf.flags.FLAGS
FLAGS._parse_flags()
print("\nParameters:")
for attr, value in sorted(FLAGS.__flags.items()):
    print("{}={}".format(attr.upper(), value))
print("")



# Data Preparatopn
# ==================================================

# Load data
print("Loading data...")
x_text, y = data_helpers.load_data_and_labels(FLAGS.data_source_positive, FLAGS.data_source_negative)
for i in range(len(x_text)):
    print x_text[i]
    print y[i]

# Build vocabulary
max_document_length = max([len(x.split(" ")) for x in x_text])
vocab_processor = learn.preprocessing.VocabularyProcessor(max_document_length)
x = np.array(list(vocab_processor.fit_transform(x_text)),dtype=np.int32)

# Randomly shuffle data
np.random.seed(123)
tf.set_random_seed(1)
shuffle_indices = np.random.permutation(np.arange(len(y)))
x_shuffled = x[shuffle_indices]
y_shuffled = y[shuffle_indices]

# Split train/test set
# TODO: This is very crude, should use cross-validation
dev_sample_index = -1 * int(0.1 * float(len(y)))
x_train, x_dev = x_shuffled[:dev_sample_index], x_shuffled[dev_sample_index:]
y_train, y_dev = y_shuffled[:dev_sample_index], y_shuffled[dev_sample_index:]
print("Vocabulary Size: {:d}".format(len(vocab_processor.vocabulary_)))
print("Train/Dev split: {:d}/{:d}".format(len(y_train), len(y_dev)))



# Load W2V embedding
# ==================================================
model = models.Word2Vec.load_word2vec_format(FLAGS.word2vec_embedding, binary=True)
initW = np.random.uniform(-0.25,0.25,(len(vocab_processor.vocabulary_), model.vector_size))
for word in model.vocab:
    idx = vocab_processor.vocabulary_.get(word)
    if idx != 0:
        initW[idx] = model[word]



# print('Start Loading Embedding!')
# filename = "/home/luu/git/deep_aspect/embeddings/glove.840B.300d.txt"
# file = open(filename,'r')
# model = {}
# for line in file.readlines():
#     row = line.strip().split(' ')
#     word = row[0]
#     embedding = [float(val) for val in row[1:]]
#     model[word] = embedding
# print('Finish Loading Embedding!')
# print('Length of embedding is: {:d}'.format(len(model)))
# file.close()
# 
# initW = np.random.uniform(-0.25,0.25,(len(vocab_processor.vocabulary_), 300))
# for word in model:
#     idx = vocab_processor.vocabulary_.get(word)
#     if idx != 0:
#         initW[idx] = model[word]



# Training
# ==================================================

best_acc = 0
best_echo = 0
with tf.Graph().as_default():
    with tf.Session(config=tf.ConfigProto(log_device_placement=False)) as sess:
        np.random.seed(123)
        tf.set_random_seed(1)
        model = CNN(max_document_length,2,len(vocab_processor.vocabulary_),FLAGS.hidden_dim,
                   list(map(int, FLAGS.filter_sizes.split(","))),
                   FLAGS.num_filters, FLAGS.l2_reg_lambda, FLAGS.learning_rate)
        
        print "Initialize variable"
        sess.run(tf.global_variables_initializer())
        
        print "Initialize embedding"
        sess.run(model.embedding_init, feed_dict={model.embedding_placeholder:initW})
        
        ################
        # Training batch
        ################
        def get_feed_dict(x, y, batch_number, mode='training'):
            ''' This function returns a feed_dict for training
            Supports both training and testing mode. Just pass in different x,y sets
            batch_number extracts the correct batch, if set to None, returns entire set
            (For testing and evaluation normally we test the entire training set at once and no need to do batching)
        
            Input Arguments
            ---------------
            x : This is either x_train or x_dev
            y: This is either y_train or y_dev
            batch_number: Integer. Indexing the batch, set to None for whole set
            mode: if Training, sets dropout to 0.5, else sets it to 1.0 (Testing cannot use dropout 0.5)
            '''
        
            if(batch_number is not None):
                # Get batch
                X = x[int(batch_number * FLAGS.batch_size):int(int(batch_number * FLAGS.batch_size) + FLAGS.batch_size)]
                Y = y[int(batch_number * FLAGS.batch_size):int(int(batch_number * FLAGS.batch_size) + FLAGS.batch_size)]
                X = np.array(X,dtype=np.int32)
                Y = np.array(Y,dtype=np.float32)
            else:
                # Get entire set as feed_dict
                X = np.array(x, dtype=np.int32)
                Y = np.array(y, dtype=np.float32)
            
            if(mode=='training'):
                drop_val = 0.5
            else:
                # Testing should use dropout 1.0
                drop_val = 1.0
        
            feed_dict = {
                        model.input_x:X, 
                        model.input_y:Y,
                        model.dropout_keep_prob:drop_val
                        }
        
            # ptr = batch_number * batch_size
            # for i in range(batch_size):
            #     X.append(x_train[ptr + i])
            #     Y.append(y_train[ptr + i])
            #     print type(y_train[ptr + i][0])
            #     print type(x_train[ptr + i][0])
            # feed_dict = {train_input[t]: X[t] for t in range(batch_size)}
            # feed_dict[dropout_keep_prob]=0.5
            # feed_dict.update({train_output[t]: Y[t] for t in range(batch_size)})
            
            return feed_dict
        
        
        no_of_batches = int(len(x_train)/FLAGS.batch_size)
        print "Start training"
        time_str = datetime.datetime.now().isoformat()
        print(time_str)
        for t in range(FLAGS.num_epochs):
            losses = []
#             for j in tqdm(range(no_of_batches)):
            for j in range(no_of_batches):
                # NOTE : Remove this tqdm is cannot install
                feed_dict = get_feed_dict(x_train, y_train, j)
#                 _, loss = sess.run([model.train_step, model.cross_entropy], feed_dict)
                _, loss = sess.run([model.train_op, model.loss], feed_dict)
                losses.append(loss)
            print("[Epoch {}] Loss={}".format(t+1, np.mean(losses)))
            if t % FLAGS.record_step == 0:
                feed_dict = get_feed_dict(x_dev, y_dev, None)
                acc = sess.run([model.accuracy], feed_dict)
                if best_acc < acc:
                    best_acc = acc
                    best_echo = t+1
                print("[Evaluate] Accuracy={}".format(acc))
                print("Best Accuracy={} at echo {}".format(best_acc,best_echo))
            time_str = datetime.datetime.now().isoformat()
            print(time_str)
    
        




