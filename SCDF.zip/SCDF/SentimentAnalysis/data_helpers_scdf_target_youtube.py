import numpy as np
import re

# def clean_str(string):
# #     newString = string.replace('.',' ').replace('#','')
# #     parts = newString.split()
# #     parts = filter(lambda z : z.startswith('@') == False, parts)
# #     newString = ' '.join(parts)
# #     return newString
#     string = re.sub(r"[^A-Za-z0-9(),!?\'\`]", " ", string)
#     string = re.sub(r"\'s", " \'s", string)
#     string = re.sub(r"\'ve", " \'ve", string)
#     string = re.sub(r"n\'t", " n\'t", string)
#     string = re.sub(r"\'re", " \'re", string)
#     string = re.sub(r"\'d", " \'d", string)
#     string = re.sub(r"\'ll", " \'ll", string)
#     string = re.sub(r",", " , ", string)
#     string = re.sub(r"!", " ! ", string)
#     string = re.sub(r"\(", " \( ", string)
#     string = re.sub(r"\)", " \) ", string)
#     string = re.sub(r"\?", " \? ", string)
#     string = re.sub(r"\s{2,}", " ", string)
#     print string
#     return string

def clean_str(string):
    newString = string
#     newString = re.sub(r"\'s", " \'s", newString)
#     newString = re.sub(r"\'ve", " have", newString)
    newString = re.sub(r"n\'t", " not", newString)
#     newString = re.sub(r"\'re", " are", newString)
#     newString = re.sub(r"\'d", " would", newString)
#     newString = re.sub(r"\'ll", " will", newString)
    parts = newString.split()
#     parts = filter(lambda z : z != 'a' and z != 'the' and z != 'an', parts)
#     newString = ' '.join(parts)
#     parts = newString.split()
    n = []
    for part in parts:
        if any(i.isdigit() for i in part):
            continue
        elif part.startswith('@'):
            continue
        elif part == '...':
            n.append('.')
        elif 'fuck' in part and part != 'fuckin' and part != 'fucking':
            n.append('fuck')
        elif part.startswith('shit'):
            n.append('shit')
        else:
            n.append(part)
    newString = ' '.join(n)
    return newString

def load_data_and_labels(data_file,filter_neutral=False,list_neutral=None,training=False,target=False,trim=False):
    """
    Loads MR polarity data from files, splits the data into words and generates labels.
    Returns split sentences and labels.
    """
    # Load data from files
#     lines = list(open(data_file, "r").readlines())
    box = []
    lines = list(open(data_file, "r").read().splitlines())
    lines = [s.strip().lower() for s in lines]
    x_text = []
    y = []
    for i in range(len(lines)):
        if filter_neutral == True:
            if list_neutral[i] == 0:
                continue
        lines[i] = lines[i].replace('not bad', 'good').replace('not good','bad').replace(';)',':)')
        s = lines[i].split('\t')
#         print lines[i]
        if target == False:
            if s[1] in box:
                continue
            else:
                box.append(s[1])
            lbl = int(s[0])
            if trim == False:
                sen = s[1]
            else:
                sen = clean_str(s[1])
            x_text.append(sen)
            
            
            if lbl == 0:
                y.append(map(np.float32,[1,0,0]))
            elif lbl == 1:
                y.append(map(np.float32,[0,1,0]))
            else:
                y.append(map(np.float32,[0,0,1]))
        else:
#             print s[2]
            lbl = int(s[1])
            if trim == False:
                sen = s[2]
            else:
                sen = clean_str(s[2])
            mess = []
#             parts = re.split('[.;|!?,]|but|unless',sen)
#             parts = re.split('[.;|!?,]|but|unless|that|so|why|what',sen)
            parts = re.split('[.;|!?,]|but|unless',sen)
            for i in range(len(parts)):
                part = parts[i].strip()
                if part.startswith(s[0] + ' ') or part.endswith(' ' + s[0]) or (' ' + s[0] + ' ') in part or part == s[0]:
                    if len(part.split(' ')) - len(s[0].split(' ')) < 4:
                        j = i
                        while j > 0:
                            if len(parts[j-1].strip()) > 0:
                                mess.append(parts[j-1].strip())
                                break
                            else:
                                j -= 1
                        mess.append(part)
                        j = i
                        while j < len(parts)-1:
                            if len(parts[j+1].strip()) > 0:
                                mess.append(parts[j+1].strip())
                                break
                            else:
                                j += 1
                    else:
                        mess.append(part)
            sen = ' '.join(mess)
#             print s[2]
#             print sen
#             print '------'
            sen = sen.replace(s[0], '***')
            x_text.append(sen)
            
            
            
            if lbl == 0:
                y.append(map(np.float32,[1,0,0]))
            elif lbl == 1:
                y.append(map(np.float32,[0,1,0]))
            else:
                y.append(map(np.float32,[0,0,1]))
        
        
    y = np.array(y)
    return [x_text, y]

def load_data(sentences, targets, trim=False):
    x_text = []
    y = []
    for sen, tar in zip(sentences, targets):
        if trim == True:
            sen = clean_str(sen)
        mess = []
        parts = re.split('[.;|!?,]|but|unless',sen)
        for i in range(len(parts)):
            part = parts[i].strip()
            if part.startswith(tar + ' ') or part.endswith(' ' + tar) or (' ' + tar + ' ') in part or part == tar:
                if len(part.split(' ')) - len(tar.split(' ')) < 4:
                    j = i
                    while j > 0:
                        if len(parts[j-1].strip()) > 0:
                            mess.append(parts[j-1].strip())
                            break
                        else:
                            j -= 1
                    mess.append(part)
                    j = i
                    while j < len(parts)-1:
                        if len(parts[j+1].strip()) > 0:
                            mess.append(parts[j+1].strip())
                            break
                        else:
                            j += 1
                else:
                    if i > 0 and len(parts[i-1].strip().split(' ')) == 1:
                        mess.append(parts[i-1].strip())
                    mess.append(part)
                    if i < len(parts)-1 and len(parts[i+1].strip().split(' ')) == 1:
                        mess.append(parts[i+1].strip())
        sen = ' '.join(mess)
        sen = sen.replace(tar, '***')
        x_text.append(sen)
        y.append(map(np.float32,[0,0,0]))
        
    y = np.array(y) 
    return x_text, y

def batch_iter(data, batch_size, num_epochs, shuffle=True):
    """
    Generates a batch iterator for a dataset.
    """
    data = np.array(data)
    data_size = len(data)
    num_batches_per_epoch = int(len(data)/batch_size) + 1
    for epoch in range(num_epochs):
        # Shuffle the data at each epoch
        if shuffle:
            shuffle_indices = np.random.permutation(np.arange(data_size))
            shuffled_data = data[shuffle_indices]
        else:
            shuffled_data = data
        for batch_num in range(num_batches_per_epoch):
            start_index = batch_num * batch_size
            end_index = min((batch_num + 1) * batch_size, data_size)
            yield shuffled_data[start_index:end_index]
            
def load_ori_target(data_file):
    lines = list(open(data_file, "r").read().splitlines())
    lines = [s.strip().lower() for s in lines]
    target = []
    sentence = []
    for line in lines:
        target.append(line.split('\t')[0])
        sentence.append(line.split('\t')[2])
    return target,sentence

