'''
Created on 20 Dec 2016

@author: luu
'''

import cPickle as pickle
import os
#os.environ['TF_CPP_MIN_LOG_LEVEL']='2'
import tensorflow as tf
import numpy as np
import preEvaluation
from data_helpers_scdf import load_data

from flask import Flask
from flask import jsonify
from flask import request
from flask import abort
from flask import render_template
import json

os.environ["CUDA_VISIBLE_DEVICES"]="-1"

tf.flags.DEFINE_string("lexicon_file", "../lexicon.txt", "Lexicon file.")
tf.flags.DEFINE_string("oneGram_file", "../Toey_onegram.txt", "One gram file.")
FLAGS = tf.flags.FLAGS
FLAGS._parse_flags()

app = Flask(__name__)

################
# Training batch
################

def get_feed_dict(x, y, input_ops, batch_number, mode='training'):
    ''' This function returns a feed_dict for training
    Supports both training and testing mode. Just pass in different x,y sets
    batch_number extracts the correct batch, if set to None, returns entire set
    (For testing and evaluation normally we test the entire training set at once and no need to do batching)

    Input Arguments
    ---------------
    x : This is either x_train or x_dev
    y: This is either y_train or y_dev
    batch_number: Integer. Indexing the batch, set to None for whole set
    mode: if Training, sets dropout to 0.5, else sets it to 1.0 (Testing cannot use dropout 0.5)
    '''

    if(batch_number is not None):
        # Get batch
        X = x[int(batch_number * FLAGS.batch_size):int(int(batch_number * FLAGS.batch_size) + FLAGS.batch_size)]
        Y = y[int(batch_number * FLAGS.batch_size):int(int(batch_number * FLAGS.batch_size) + FLAGS.batch_size)]
        X = np.array(X,dtype=np.int32)
        Y = np.array(Y,dtype=np.float32)
    else:
        # Get entire set as feed_dict
        X = np.array(x, dtype=np.int32)
        Y = np.array(y, dtype=np.float32)
    
    if(mode=='training'):
        drop_val = FLAGS.dropout_keep_prob
    else:
        # Testing should use dropout 1.0
        drop_val = 1.0

    feed_dict = {
                input_ops[0]:X, 
                input_ops[1]:Y,
                input_ops[2]:drop_val
                }
    
    return feed_dict

saver = tf.train.import_meta_graph("../SavedModels/Sentence_level/Twitter/model.ckpt.meta")
sess = tf.Session()
saver.restore(sess,"../SavedModels/Sentence_level/Twitter/model.ckpt")
input_ops = tf.get_collection('input')
result_ops = tf.get_collection('result')

@app.route('/api/v1.0/predict', methods=['POST'])
def predict():
    data = request.get_json()
    # data = jsonify(json.loads(request.data))
    if('sentence' not in data):
        abort(400)
    sentence = data['sentence']
    neutral = preEvaluation.checkNeutralSentences(FLAGS.lexicon_file, FLAGS.oneGram_file,sentence)
    x_test,y_test = load_data(sentence,trim=True)
    
    word_to_id = {}
    with open('../SavedDict/Sentence_level/Twitter/dict.txt','r') as f:
        lines = f.readlines()
        for line in lines:
            parts = line.strip().split('***+++###!!!***')
            word_to_id[parts[0]] = int(parts[1])
    
    # Build vocabulary
    max_document_length = 50

 
    temp = []
    for x in x_test:
        t = []
        for e in x.split(' '):
            if e in word_to_id:
                t.append(word_to_id[e])
            else:
                t.append(1)
        for i in range(max_document_length - len(x.split(' '))):
            t.append(0)
        t = np.array(t,dtype=np.int32)
        temp.append(t)
    x_test = np.array(list(temp),dtype=np.int32)
    # Training
    # ==================================================  
    feed_dict = get_feed_dict(x_test, y_test, input_ops, None,'testing')
    print 'start predicting'
    _,predict = sess.run([result_ops[0],result_ops[1]], feed_dict)
    print 'finish predicting'
    for i in range(len(neutral)):
        if neutral[i] == 0:
            predict[i] = 1
    predict = int(predict[0])
    print('Prediction={}'.format(predict))
    return jsonify({'prediction':predict})
    return predict

if __name__ == '__main__':
    app.run(debug=False, port=6000)

# sentences, targets, all_labels = [], [], []
# 
# with open(FLAGS.test_set,'r') as f:
#     lines = f.read().splitlines()
#     lines = [s.strip().lower() for s in lines]
#     for line in lines:
#         s = line.split('\t')
#         sentences.append(s[2])
#         targets.append(s[0])
#         all_labels.append(int(s[1]))
# 
# predict = test(sentences,targets)
# 
# performanceEvaluation.evaluate(all_labels, predict)
# performanceEvaluation.printout(all_labels, predict,sentences,sentences,targetList=targets,target=True)
