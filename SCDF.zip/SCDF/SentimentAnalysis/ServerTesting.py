'''
Created on 6 Dec 2017

@author: luu
'''

from Server import test

# def main():
#     sentence = raw_input("Enter the sentence:")
# #     target = raw_input("Enter the target:")
#     sentences, targets = [],[]
#     sentences.append(sentence)
# #     targets.append(target)
#     predict = test(sentences)
#     print predict[0]

def main():
    with open('../Dataset/test_twitter.txt','r') as f:
        lines = f.read().splitlines()
        sentences = []
        for line in lines:
            sentences.append(line)
        predict = test(sentences)
        for i in predict:
            print i
    
if __name__ == "__main__":
    main()
