import os
os.environ['TF_CPP_MIN_LOG_LEVEL']='2'
import tensorflow as tf
import numpy as np
import datetime
import data_helpers_scdf
import preEvaluation
from CNN_Model import CNN
from gensim import models
from sklearn.metrics import f1_score
from sklearn.metrics import recall_score
from sklearn.metrics import precision_score
#import timeit
import performanceEvaluation


# Set the genre
genre = 'Twitter'

# Set seed of random
np.random.seed(123)

# Parameters
# ==================================================

#start = timeit.default_timer()

# Data loading params
tf.flags.DEFINE_string("train_set", "../Dataset/" + genre +"/train.txt", "Data source for the training data.")
tf.flags.DEFINE_string("dev_set", "../Dataset/" + genre + "/dev.txt", "Data source for the development data.")
tf.flags.DEFINE_string("test_set", "../Dataset/" + genre + "/test.txt", "Data source for the testing data.")

tf.flags.DEFINE_string("word2vec_embedding", "/home/luu/Downloads/GoogleNews-vectors-negative300.bin", "Word2Vec embedding file")
# tf.flags.DEFINE_string("word2vec_embedding", "/home/luu/git/deep_aspect/embeddings/gloveInWord2Vec.840B.300d.txt", "Glove embedding file")

# Model Hyperparameters
tf.flags.DEFINE_integer("input_dim", 300, "Dimensionality of hidden layer")
tf.flags.DEFINE_float("dropout_keep_prob", 1, "Dropout keep probability (default: 1)")
tf.flags.DEFINE_string("filter_sizes", "1,2", "Comma-separated filter sizes (default: '1,2')")
tf.flags.DEFINE_integer("num_filters", 100, "Number of filters per filter size (default: 100)")
tf.flags.DEFINE_float("l2_reg_lambda", 1, "L2 regularizaion lambda (default: 1.0)")
tf.flags.DEFINE_float("learning_rate", 0.0001, "Learning rate (default: 0.001)")

# Training parameters
tf.flags.DEFINE_integer("batch_size", 100, "Batch Size (default: 100)")
tf.flags.DEFINE_integer("num_epochs", 100, "Number of training epochs (default: 100)")
tf.flags.DEFINE_integer("record_step", 1, "Evaluate model on dev set after this many steps (default: 1)")

# Lexicon files
tf.flags.DEFINE_string("lexicon_file", "/home/luu/Downloads/NeutralFillter/lexicon.txt", "Lexicon file.")
tf.flags.DEFINE_string("oneGram_file", "/home/luu/Downloads/NeutralFillter/Toey_onegram.txt", "One gram file.")

FLAGS = tf.flags.FLAGS
FLAGS._parse_flags()
print("\nParameters:")
for attr, value in sorted(FLAGS.__flags.items()):
    print("{}={}".format(attr.upper(), value))
print("")


# Data preparation and pre-processing 
# ==================================================
neutral = preEvaluation.checkNeutralFile(FLAGS.lexicon_file, FLAGS.oneGram_file, FLAGS.test_set)
train_neutral = preEvaluation.checkNeutralFile(FLAGS.lexicon_file, FLAGS.oneGram_file, FLAGS.train_set)


# Load data
print("Loading data...")
# x_train, y_train = data_helpers_scdf_target_youtube.load_data_and_labels(FLAGS.train_set,filter_neutral=True,list_neutral=train_neutral)
x_train, y_train = data_helpers_scdf.load_data_and_labels(FLAGS.train_set,training = True)
x_dev, y_dev = data_helpers_scdf.load_data_and_labels(FLAGS.dev_set)
x_test, y_test = data_helpers_scdf.load_data_and_labels(FLAGS.test_set)
x_realtest = x_test

x_data = x_train + x_dev + x_test

idt = 1
id_to_word = {}
word_to_id = {}
id_to_word[0] = '<pad>'
word_to_id['<pad'] = 0
id_to_word[1] = '<unk>'
word_to_id['<unk'] = 1
for x in x_data:
    for p in x.split(' '):
        if p in word_to_id:
            continue
        else:
            word_to_id[p] = idt
            id_to_word[idt] = p
            idt += 1

# Save dictionary
with open('../SavedDict/Sentence_level/' + genre + '/dict.txt','w') as f:
    for word in word_to_id:
        f.write(word + "***+++###!!!***" + str(word_to_id[word]) + '\n')

# Build vocabulary
# max_document_length = max([len(x.split(" ")) for x in x_data])
# print max_document_length
max_document_length = 50

print("Vocabulary Size: {:d}".format(len(id_to_word)))

temp = []
for x in x_train:
    t = []
    for e in x.split(' '):
        t.append(word_to_id[e])
    for i in range(max_document_length - len(x.split(' '))):
        t.append(0)
    t = np.array(t,dtype=np.int32)
    temp.append(t)
x_train = np.array(list(temp),dtype=np.int32)

temp = []
for x in x_test:
    t = []
    for e in x.split(' '):
        t.append(word_to_id[e])
    for i in range(max_document_length - len(x.split(' '))):
        t.append(0)
    t = np.array(t,dtype=np.int32)
    temp.append(t)
x_test = np.array(list(temp),dtype=np.int32)

temp = []
for x in x_dev:
    t = []
    for e in x.split(' '):
        t.append(word_to_id[e])
    for i in range(max_document_length - len(x.split(' '))):
        t.append(0)
    t = np.array(t,dtype=np.int32)
    temp.append(t)
x_dev = np.array(list(temp),dtype=np.int32)


# Load W2V embedding
# ==================================================
model = models.Word2Vec.load_word2vec_format(FLAGS.word2vec_embedding, binary=True)
initW = np.random.uniform(-0.0001,0.0001,(len(word_to_id), FLAGS.input_dim))
for word in model.vocab:
    if word in word_to_id:
        initW[word_to_id[word]] = model[word]



# print('Start Loading Embedding!')
# filename = "/home/luu/git/deep_aspect/embeddings/glove.840B.300d.txt"
# file = open(filename,'r')
# model = {}
# for line in file.readlines():
#     row = line.strip().split(' ')
#     word = row[0]
#     embedding = [float(val) for val in row[1:]]
#     model[word] = embedding
# print('Finish Loading Embedding!')
# print('Length of embedding is: {:d}'.format(len(model)))
# file.close()
# 
# initW = np.random.uniform(-0.25,0.25,(len(vocab_processor.vocabulary_), 300))
# for word in model:
#     idx = vocab_processor.vocabulary_.get(word)
#     if idx != 0:
#         initW[idx] = model[word]


# Training
# ==================================================

best_acc = 0
best_echo = 0
best_result = []
best_all_labels = []
with tf.Graph().as_default():
    with tf.Session(config=tf.ConfigProto(log_device_placement=False)) as sess:   
        np.random.seed(123)
        tf.set_random_seed(1)
        model = CNN(max_document_length,3,len(word_to_id),FLAGS.input_dim,
                   list(map(int, FLAGS.filter_sizes.split(","))),
                   FLAGS.num_filters, FLAGS.l2_reg_lambda, FLAGS.learning_rate)
        
        print "Initialize variable"
        sess.run(tf.global_variables_initializer())
        
        print "Initialize embedding"
        sess.run(model.embedding_init, feed_dict={model.embedding_placeholder:initW})
        
        ################
        # Training batch
        ################
        def get_feed_dict(x, y, batch_number, mode='training'):
            ''' This function returns a feed_dict for training
            Supports both training and testing mode. Just pass in different x,y sets
            batch_number extracts the correct batch, if set to None, returns entire set
            (For testing and evaluation normally we test the entire training set at once and no need to do batching)
        
            Input Arguments
            ---------------
            x : This is either x_train or x_dev
            y: This is either y_train or y_dev
            batch_number: Integer. Indexing the batch, set to None for whole set
            mode: if Training, sets dropout to 0.5, else sets it to 1.0 (Testing cannot use dropout 0.5)
            '''
        
            if(batch_number is not None):
                # Get batch
                X = x[int(batch_number * FLAGS.batch_size):int(int(batch_number * FLAGS.batch_size) + FLAGS.batch_size)]
                Y = y[int(batch_number * FLAGS.batch_size):int(int(batch_number * FLAGS.batch_size) + FLAGS.batch_size)]
                X = np.array(X,dtype=np.int32)
                Y = np.array(Y,dtype=np.float32)
            else:
                # Get entire set as feed_dict
                X = np.array(x, dtype=np.int32)
                Y = np.array(y, dtype=np.float32)
            
            if(mode=='training'):
                drop_val = FLAGS.dropout_keep_prob
            else:
                # Testing should use dropout 1.0
                drop_val = 1.0
        
            feed_dict = {
                        model.input_x:X, 
                        model.input_y:Y,
                        model.dropout_keep_prob:drop_val
                        }
            
            return feed_dict
        
        
        no_of_batches = int(len(x_train)/FLAGS.batch_size)
        print "Start training"
        time_str = datetime.datetime.now().isoformat()
        print(time_str)
        for t in range(FLAGS.num_epochs):
            losses = []
            shuffle_indices = np.random.permutation(np.arange(len(x_train)))
            x_train = x_train[shuffle_indices]
            y_train = y_train[shuffle_indices]
#             for j in tqdm(range(no_of_batches)):
            for j in range(no_of_batches):
                # NOTE : Remove this tqdm is cannot install
                feed_dict = get_feed_dict(x_train, y_train, j)
#                 _, loss = sess.run([model.train_step, model.cross_entropy], feed_dict)
                _, loss = sess.run([model.train_op, model.loss], feed_dict)
                losses.append(loss)
            print("[Epoch {}] Loss={}".format(t+1, np.mean(losses)))
            
            if t % FLAGS.record_step == 0:
                feed_dict = get_feed_dict(x_dev, y_dev, None,'testing')
                pred_ops,predict,acc = sess.run([model.pred_ops,model.predictions,model.accuracy], feed_dict)
                all_labels = []
                for i in y_dev:
                    if i[0] == 1:
                        all_labels.append(0)
                    elif i[1] == 1:
                        all_labels.append(1)
                    else:
                        all_labels.append(2)
                f1 = f1_score(all_labels,predict, average='macro')
                recall = recall_score(all_labels,predict, average='macro')
                precision = precision_score(all_labels,predict, average='macro')
                print("[Evaluate] Dev Accuracy={}, F1={}, P={}, R= {}".format(acc,f1,recall,precision))
                        
        
                feed_dict = get_feed_dict(x_test, y_test, None,'testing')
                pred_ops,predict,acc = sess.run([model.pred_ops,model.predictions,model.accuracy], feed_dict)
                all_labels = []
                for i in y_test:
                    if i[0] == 1:
                        all_labels.append(0)
                    elif i[1] == 1:
                        all_labels.append(1)
                    else:
                        all_labels.append(2)
                for i in range(len(neutral)):
                    if neutral[i] == 0:
                        predict[i] = 1
                
                f1 = f1_score(all_labels,predict, average='macro')
                recall = recall_score(all_labels,predict, average='macro')
                precision = precision_score(all_labels,predict, average='macro')
                print("[Evaluate] Test Accuracy={}, F1={}, P={}, R= {}".format(acc,f1,recall,precision))
                        
                if best_acc < f1:
                    best_result = predict
                    best_all_labels = all_labels
                    best_acc = f1
                    best_echo = t+1
        
                    print("Saving model..")
                    saver = tf.train.Saver()
                    saver.save(sess, "../SavedModels/Sentence_level/" + genre + "/model.ckpt")
                    with open('../SavedResults/Sentence_level/' + genre + '/result.txt','w') as f:
                        for r in pred_ops:
                            f.write(str(r[0]) + '\t' + str(r[1]) + '\n')
                
                print("Best F1={} at echo {}".format(best_acc,best_echo))
                print("------------------------------------------------")

performanceEvaluation.evaluate(best_all_labels, best_result)
performanceEvaluation.printout(best_all_labels, best_result, x_realtest)
# performanceEvaluation.printout(best_all_labels, best_result,sentence,targetList=target,target=True)
# stop = timeit.default_timer()
# print('Processing time is {:f}'.format(stop - start)) 