from __future__ import division

def printout(gold, dnn, sentence,x_realtest = None,targetList=None,target=False):
    if target == False:
        for i in range(len(gold)):
            if dnn[i] == 0 and gold[i]!= 0:
                print sentence[i]
    else:
        if x_realtest != None:     
            for i in range(len(gold)):
                if dnn[i] != 0 and gold[i]== 0:
                    print targetList[i], '###', sentence[i], '###', x_realtest[i], '###',dnn[i], '###',gold[i]
        else:
            for i in range(len(gold)):
                if dnn[i] != 2 and gold[i]== 2:
                    print targetList[i], '###', sentence[i], '###', dnn[i], '###',gold[i]

def evaluate(gold, dnn):
    print_info = ""

    em = [[0, 0, 0, 0],
          [0, 0, 0, 0],
          [0, 0, 0, 0],
          [0, 0, 0, 0]]

    for i in range(len(gold)):
        g = int(gold[i])
        p = int(dnn[i])
        em[g][p] = em[g][p] + 1
        em[g][3] = em[g][3] + 1
        em[3][p] = em[3][p] + 1
        em[3][3] = em[3][3] + 1
        
    print_info = print_info + "G\\P:\t0\t\t1\t\t2\n"
    for i in range(len(em)):
        print_info = print_info + str(i) + " :\t"
        for j in range(len(em[i])):
            print_info = print_info + str(em[i][j]) + "\t"
        print_info = print_info + "\n"

    print_info = print_info + "\n"
    title = ["NEG", "NEU", "POS"]
    perf = [[em[0][0] / em[3][0], em[0][0] / em[0][3], 0],  #NEG
                   [em[1][1]/em[3][1], em[1][1]/em[1][3], 0],  #NEU
                   [em[2][2]/em[3][2], em[2][2]/em[2][3], 0]]  #POS
    perf[0][2] = (2 * perf[0][0] * perf[0][1]) / (perf[0][0] + perf[0][1])
    perf[1][2] = (2 * perf[1][0] * perf[1][1]) / (perf[1][0] + perf[1][1])
    perf[2][2] = (2 * perf[2][0] * perf[2][1]) / (perf[2][0] + perf[2][1])

    print_info = print_info + "P\\G:\tP\t\tR\t\tF\n"
    for i in range(len(perf)):
        print_info = print_info + title[i] + " :\t"
        for j in range(len(perf[i])):
            print_info = print_info + str(perf[i][j]) + " :\t"
        print_info = print_info + "\n"

    perf_no_neu = [(em[0][0]+em[2][2]) / (em[3][0]+em[3][2]),
                   (em[0][0] + em[2][2]) / (em[0][3] + em[2][3]),
                   0]
    perf_no_neu[2] = 2*perf_no_neu[0]*perf_no_neu[1]/(perf_no_neu[0]+perf_no_neu[1])

    print_info = print_info + "w/o NEU: "
    print_info = print_info + str(perf_no_neu[0]) + "\t"
    print_info = print_info + str(perf_no_neu[1]) + "\t"
    print_info = print_info + str(perf_no_neu[2]) + "\t"
    print_info = print_info + "\nACC= " + str((em[0][0]+em[1][1]+em[2][2])/em[3][3])
    print(print_info)
